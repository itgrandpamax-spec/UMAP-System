from django.contrib import messages
from django.shortcuts import redirect, render
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse
from .forms import UserRegistrationForm
from .models import User

def default_view(request):
    return render(request, 'UMAP_App/Users/Users_main.html')

def logout_view(request):
    auth_logout(request)
    return redirect('default_view')

def signup_view(request):
    if request.method == 'POST':
        post_data = request.POST.copy()  # Make a mutable copy
        # Set user type to regular by default for security
        post_data['type'] = 'regular'
        form = UserRegistrationForm(post_data)
        if form.is_valid():
            try:
                user = form.save()
                messages.success(request, 'Registration successful. Please login.')
            except Exception as e:
                messages.error(request, str(e))
        else:
            # Get all error messages
            error_message = '; '.join([f"{field}: {error[0]}" for field, error in form.errors.items()])
            messages.error(request, f'Registration failed: {error_message}')
    return redirect('login')

@login_required
def admin_user_list_view(request):
    if not request.user.is_staff and not request.user.is_superuser:
        messages.error(request, "You are not authorized to access the admin page.")
        return redirect('login')
    users = User.objects.all().select_related('profile')
    return render(request, 'UMAP_App/Admin/Admin_User_List.html', {'users': users})

def admin_profile_view(request):
    return render(request, 'UMAP_App/Admin/Admin_Profile.html')

def admin_floor_list_view(request):
    return render(request, 'UMAP_App/Admin/Admin_Map_List.html')

def admin_rooms_list_view(request):
    return render(request, 'UMAP_App/Admin/Admin_Rooms.html')

def admin_CRUD_Users_view(request):
    return render(request, 'UMAP_App/Admin/Admin_CRUD_Users.html')

def admin_CRUD_Floors_view(request):
    return render(request, 'UMAP_App/Admin/Admin_CRUD_Floors.html')

def admin_CRUD_Rooms_view(request):
    return render(request, 'UMAP_App/Admin/Admin_CRUD_Rooms.html')

def login_view(request):
    """Handle GET (show form) and POST (authenticate) for login."""
    if request.user.is_authenticated:
        if request.user.is_superuser or request.user.is_staff:
            return redirect('admin_main_view')
        else:
            return redirect('user_main_view')

    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        
        try:
            # First check if the user exists in our database
            user_exists = User.objects.filter(username=username).exists()
            if not user_exists:
                messages.error(request, "User does not exist. Please register first.")
                return redirect('login')
            
            # Then try to authenticate
            user = authenticate(request, username=username, password=password)
            if user is not None and user.is_active:
                auth_login(request, user)
                if user.is_superuser or user.is_staff:
                    return redirect('admin_main_view')
                else:
                    return redirect('user_main_view')
            else:
                messages.error(request, "Invalid password. Please try again.")
                return redirect('login')
        except Exception as e:
            messages.error(request, "An error occurred during login. Please try again.")
            return redirect('login')

    return render(request, 'UMAP_App/Users/Users_main.html')

@login_required
def admin_main_view(request):
    if not request.user.is_staff and not request.user.is_superuser:
        messages.error(request, "You are not authorized to access the admin page.")
        return redirect('UMAP_App/auth/Login.html')
    return render(request, 'UMAP_App/Admin/Admin_main.html')

@login_required
def user_main_view(request):
    response = redirect('default_view')
    # Add cache control headers to force a fresh page load
    response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response['Pragma'] = 'no-cache'
    response['Expires'] = '0'
    return response
