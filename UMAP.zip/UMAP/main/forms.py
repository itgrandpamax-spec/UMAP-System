from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, Profile

class UserRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(required=True)
    last_name = forms.CharField(required=True)
    student_id = forms.CharField(required=True)
    department = forms.ChoiceField(
        choices=[
            ('IT', 'Information Technology'),
            ('CS', 'Computer Science'),
            ('Engineering', 'Engineering'),
            ('Business', 'Business'),
            ('Arts', 'Arts')
        ],
        required=True
    )
    year_level = forms.ChoiceField(
        choices=[
            ('1', '1st Year'),
            ('2', '2nd Year'),
            ('3', '3rd Year'),
            ('4', '4th Year')
        ],
        required=True
    )
    type = forms.ChoiceField(
        choices=User.UserType.choices,
        initial=User.UserType.REGULAR,
        required=True
    )

    class Meta:
        model = User
        fields = ('username', 'email', 'first_name', 'last_name', 'password1', 'password2', 'type')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.type = User.UserType.REGULAR  # Force regular user type for security
        
        if commit:
            user.save()
            # Create associated profile
            Profile.objects.create(
                user=user,
                email=self.cleaned_data['email'],
                department=self.cleaned_data['department'],
                year_level=int(self.cleaned_data['year_level']),
                student_id=self.cleaned_data['student_id']
            )
        return user

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2', 'type')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({
            'class': 'mt-1 w-full rounded-lg border border-gray-300 p-2 focus:border-indigo-500 focus:outline-none'
        })
        self.fields['password1'].widget.attrs.update({
            'class': 'mt-1 w-full rounded-lg border border-gray-300 p-2 focus:border-indigo-500 focus:outline-none'
        })
        self.fields['password2'].widget.attrs.update({
            'class': 'mt-1 w-full rounded-lg border border-gray-300 p-2 focus:border-indigo-500 focus:outline-none'
        })

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.first_name = self.cleaned_data['first_name']
        user.last_name = self.cleaned_data['last_name']
        user.type = self.cleaned_data['type']
        
        if commit:
            user.save()
            # Create associated profile
            Profile.objects.create(
                user=user,
                email=self.cleaned_data['email'],
                department=self.cleaned_data.get('department', ''),
                year_level=self.cleaned_data.get('year_level')
            )
        return user
