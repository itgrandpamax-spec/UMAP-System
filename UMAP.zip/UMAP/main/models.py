from django.db import models
from django.contrib.auth.models import AbstractUser



# USER MODEL
class User(AbstractUser):
    class UserType(models.TextChoices):
        GUEST = 'guest', 'Guest'
        REGULAR = 'regular', 'Regular'
        ADMIN = 'admin', 'Admin'

    type = models.CharField(max_length=10, choices=UserType.choices, default=UserType.GUEST)
    status = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.username} ({self.get_type_display()})"



# ADMIN MODEL (optional extension of User)
class Admin(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='admin_profile')
    edit_history = models.TextField(blank=True)

    def __str__(self):
        return f"Admin: {self.user.username}"



# USER PROFILE
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    email = models.EmailField(unique=True)
    department = models.CharField(max_length=100, blank=True)
    year_level = models.PositiveIntegerField(null=True, blank=True)
    description = models.TextField(blank=True)
    profile_pic = models.ImageField(upload_to='profiles/', blank=True, null=True)

    def __str__(self):
        return f"{self.user.username}'s Profile"



# FLOOR MODEL
class Floor(models.Model):
    name = models.CharField(max_length=100)
    building = models.CharField(max_length=100)
    creation_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.building})"



# ROOM MODEL
class Room(models.Model):
    floor = models.ForeignKey(Floor, on_delete=models.CASCADE, related_name='rooms')
    creation_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Room {self.id} - Floor: {self.floor.name}"



# ROOM PROFILE MODEL
class RoomProfile(models.Model):
    room = models.OneToOneField(Room, on_delete=models.CASCADE, related_name='profile')
    number = models.CharField(max_length=50)
    name = models.CharField(max_length=100)
    type = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    images = models.ImageField(upload_to='rooms/', blank=True, null=True)
    coordinates = models.JSONField(default=dict)

    def __str__(self):
        return f"{self.name} ({self.number})"



# CLASS SCHEDULE MODEL
class Schedule(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='schedules')
    room = models.ForeignKey(Room, on_delete=models.CASCADE, related_name='schedules')
    course_code = models.CharField(max_length=50)
    subject = models.CharField(max_length=100)
    day = models.CharField(max_length=20)
    start = models.TimeField()
    end = models.TimeField()
    color = models.CharField(max_length=20)

    def __str__(self):
        return f"{self.subject} ({self.course_code}) - {self.day}"



# FEEDBACK MODEL
class Feedback(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='feedbacks')
    room = models.ForeignKey(Room, on_delete=models.CASCADE, related_name='feedbacks')
    creation_date = models.DateTimeField(auto_now_add=True)
    rating = models.PositiveSmallIntegerField()
    comment = models.TextField(blank=True)

    def __str__(self):
        return f"Feedback by {self.user.username} on Room {self.room.id}"
