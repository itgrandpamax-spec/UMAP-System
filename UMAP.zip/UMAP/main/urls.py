from django.urls import path
from . import views

urlpatterns = [
    path('', views.default_view, name='default_view'),
    path('login/', views.login_view, name='login'),
    path('signup/', views.signup_view, name='signup'),
    path('logout/', views.logout_view, name='logout'),

    path('user_main/', views.user_main_view, name='user_main_view'),

    path('admin_profile/', views.admin_profile_view, name='admin_profile_view'),
    path('admin_main/', views.admin_main_view, name='admin_main_view'),
    path('admin_users/', views.admin_user_list_view, name='admin_user_list'),
    path('admin_floors/', views.admin_floor_list_view, name='admin_floor_list'),
    path('admin_rooms/', views.admin_rooms_list_view, name='admin_rooms_list'),
    path('admin_CRUD_Users/', views.admin_CRUD_Users_view, name='admin_CRUD_Users'),
    path('admin_CRUD_Floors/', views.admin_CRUD_Floors_view, name='admin_CRUD_Floors'),
    path('admin_CRUD_Rooms/', views.admin_CRUD_Rooms_view, name='admin_CRUD_Rooms'),
]
